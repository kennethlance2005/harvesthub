// customer.js — Community Gardener dashboard logic

// ---------- Core Utility Functions ----------
function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

function showToast(message, type = 'success') {
  const toastEl = document.createElement('div');
  toastEl.className = `toast${type === 'danger' ? ' toast-danger' : ''}`;
  toastEl.textContent = message;
  const container = document.getElementById('toast-container');
  if (container) container.appendChild(toastEl);
  setTimeout(() => toastEl.remove(), 3500);
}

async function postAction(action, params) {
  const res = await fetch('api.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ action, ...params }),
  });
  return res.json();
}

// ---------- Unassign confirmation modal ----------
const unassignModal = document.getElementById('unassign-modal');
const unassignModalBody = document.getElementById('unassign-modal-body');
const unassignCancelBtn = document.getElementById('unassign-cancel');
const unassignConfirmBtn = document.getElementById('unassign-confirm');
let pendingUnassign = null; // { pltId, label }

function openUnassignModal(pltId, label) {
  pendingUnassign = { pltId, label };
  unassignModalBody.textContent = `Are you sure you want to request unassignment for "${label}"? This will be sent to the Coordinator for review.`;
  unassignModal.hidden = false;
  unassignConfirmBtn.focus();
}

function closeUnassignModal() {
  if (unassignModal) unassignModal.hidden = true;
  pendingUnassign = null;
}

if (unassignCancelBtn) unassignCancelBtn.addEventListener('click', closeUnassignModal);
if (unassignModal) {
  unassignModal.addEventListener('click', (e) => {
    if (e.target === unassignModal) closeUnassignModal();
  });
}
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && unassignModal && !unassignModal.hidden) closeUnassignModal();
});

if (unassignConfirmBtn) {
  unassignConfirmBtn.addEventListener('click', async () => {
    if (!pendingUnassign) return;
    const { pltId } = pendingUnassign;
    closeUnassignModal();

    try {
      const result = await postAction('request_plot_unassignment', { plt_id: pltId });
      if (result.ok) {
        showToast('Unassignment request submitted.', 'success');
        loadPlot();
      } else {
        showToast(result.error || 'Could not submit unassignment request.', 'danger');
      }
    } catch (err) {
      showToast('Network error while requesting unassignment.', 'danger');
    }
  });
}

// ---------- Plot ----------

async function loadPlot() {
  try {
    const res = await fetch('api.php?action=my_plot');
    const data = await res.json();
    const el = document.getElementById('plot-status');
    const btn = document.getElementById('request-plot-btn');
    if (!data.ok) return;

    // Ensure button is visible initially unless they have a pending app and 0 plots
    if (btn && document.getElementById('available-plots').hidden) {
      btn.hidden = false;
    }

    if (data.plots.length > 0) {
      const pendingUnassignment = data.pending_application?.RequestType === 'Unassign';
      el.innerHTML = `
        <p class="text-muted" style="font-size: 0.85rem; margin: 0 0 8px;">Your currently assigned plots:</p>
        <ul style="margin: 0; padding-left: 18px;">
          ${data.plots.map(plot => `
            <li style="margin-bottom: 10px;">
              <strong>${escapeHtml(plot.Label)}</strong>
              <button class="btn btn-ghost btn-sm unassign-plot-btn" data-id="${plot.PltID}" data-label="${escapeHtml(plot.Label)}" type="button" style="margin-left: 8px;" ${pendingUnassignment ? 'disabled' : ''}>${pendingUnassignment ? 'Unassignment pending' : 'Request unassignment'}</button>
            </li>
          `).join('')}
        </ul>
        <p class="text-muted" style="font-size: 0.85rem; margin-top: 12px;">Log your crops and resource needs using the panels alongside this one.</p>
      `;
      if (data.pending_application?.RequestType === 'Unassign') {
        el.insertAdjacentHTML('beforeend', `<p class="form-alert" style="display:block; background:#f3e9d6; color:#8a5a1e;">Your request to unassign <strong>${escapeHtml(data.pending_application.Label)}</strong> is pending Coordinator approval.</p>`);
      }
      
      if (btn && document.getElementById('available-plots').hidden) {
        btn.textContent = 'Request another plot';
      }

      document.querySelectorAll('.unassign-plot-btn').forEach(button => {
        button.addEventListener('click', () => {
          openUnassignModal(button.dataset.id, button.dataset.label);
        });
      });
      return;
    }

    if (data.pending_application) {
      el.innerHTML = `
        <p class="form-alert" style="display:block; background:#f3e9d6; color:#8a5a1e;">
          Application for <strong>${escapeHtml(data.pending_application.Label)}</strong> is pending Coordinator approval.
        </p>
      `;
      // Fully hide the request button if they have 0 plots and an application is pending
      if (btn) btn.hidden = true;
      document.getElementById('available-plots').hidden = true;
      return;
    }

    // Default: 0 plots, 0 pending
    el.innerHTML = `<p class="text-muted" style="font-size: 0.9rem;">You don't have a plot yet. Click the button below to request one.</p>`;
    if (btn && document.getElementById('available-plots').hidden) {
      btn.textContent = 'Request a plot';
    }
  } catch (err) {
    console.error("Error loading plots:", err);
  }
}

// ---------- Request More Plots ----------
const plotBtn = document.getElementById('request-plot-btn');
const plotAlert = document.getElementById('plot-request-alert');
const plotSuccess = document.getElementById('plot-request-success');
const availablePlotsEl = document.getElementById('available-plots');

function renderAvailablePlots(plots) {
  if (plots.length === 0) {
    availablePlotsEl.innerHTML = '<p class="text-muted" style="font-size: 0.85rem;">No plots are available right now. Check back later.</p>';
    return;
  }

  availablePlotsEl.innerHTML = `
    <p class="text-muted" style="font-size: 0.85rem; margin: 0 0 8px;">Choose an available plot to request:</p>
    <div class="inline-form" style="display: flex; gap: 8px; margin-top: 8px;">
      <select id="more-plot-select" class="field" style="flex: 1; margin-bottom: 0; padding: 10px 12px; border: 1px solid var(--line); border-radius: var(--radius); background: var(--cream-100); font-family: var(--font-body); font-size: 0.95rem;">
        ${plots.map(plot => `<option value="${plot.PltID}">${escapeHtml(plot.Label)}</option>`).join('')}
      </select>
      <button type="button" class="btn btn-accent btn-sm" id="more-plot-apply" style="height: 42px;">Submit Request</button>
    </div>
  `;

  document.getElementById('more-plot-apply').addEventListener('click', async () => {
    const applyBtn = document.getElementById('more-plot-apply');
    applyBtn.disabled = true;
    plotAlert.hidden = true;
    plotSuccess.hidden = true;

    try {
      const result = await postAction('apply_plot', {
        plt_id: document.getElementById('more-plot-select').value,
      });

      if (result.ok) {
        plotSuccess.textContent = 'Plot request submitted for Coordinator approval.';
        plotSuccess.hidden = false;
        availablePlotsEl.hidden = true;
        loadPlot();
      } else {
        plotAlert.textContent = result.error || 'Could not submit plot request.';
        plotAlert.hidden = false;
        applyBtn.disabled = false;
      }
    } catch (err) {
      plotAlert.textContent = 'Network error while requesting plot.';
      plotAlert.hidden = false;
      applyBtn.disabled = false;
    }
  });
}

if (plotBtn) {
  plotBtn.addEventListener('click', async () => {
    if (!availablePlotsEl.hidden) {
      availablePlotsEl.hidden = true;
      const currentPlotsContent = document.getElementById('plot-status').innerHTML;
      plotBtn.textContent = currentPlotsContent.includes('currently assigned') ? 'Request another plot' : 'Request a plot';
      return;
    }

    plotAlert.hidden = true;
    plotSuccess.hidden = true;
    plotBtn.disabled = true;

    try {
      const res = await fetch('api.php?action=my_plot');
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data.error || 'Could not load available plots.');

      renderAvailablePlots(data.available_plots);
      availablePlotsEl.hidden = false;
      plotBtn.textContent = 'Cancel request';
    } catch (err) {
      plotAlert.textContent = err.message;
      plotAlert.hidden = false;
    } finally {
      plotBtn.disabled = false;
    }
  });
}

// ---------- Crop Log ----------

async function loadCropLog() {
  const res = await fetch('api.php?action=my_croplog');
  const data = await res.json();
  const el = document.getElementById('croplog-list');
  if (!data.ok) return;

  if (data.logs.length === 0) {
    el.innerHTML = '<p class="text-muted" style="font-size: 0.88rem;">No entries yet.</p>';
    return;
  }

  el.innerHTML = data.logs.map(log => `
    <div style="border-bottom: 1px solid var(--line); padding: 10px 0;">
      <div style="display:flex; justify-content: space-between;">
        <strong style="font-size: 0.9rem; color: var(--ink-900);">${escapeHtml(log.CropName)}</strong>
        <span class="text-muted" style="font-size: 0.72rem;">${escapeHtml(log.LoggedAt)}</span>
      </div>
      ${log.MaintenanceNotes ? `<div class="text-muted" style="font-size: 0.85rem; margin-top: 4px;">${escapeHtml(log.MaintenanceNotes)}</div>` : ''}
      ${log.HarvestYield ? `<div style="font-size: 0.85rem; margin-top: 4px; color: var(--ink-900);">Yield: ${escapeHtml(log.HarvestYield)}</div>` : ''}
    </div>
  `).join('');
}

const croplogForm = document.getElementById('croplog-form');
if (croplogForm) {
  croplogForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const alertEl = document.getElementById('croplog-alert');
    alertEl.hidden = true;

    const cropName = document.getElementById('crop-name').value.trim();
    if (cropName === '') {
      alertEl.textContent = 'Crop name is required.';
      alertEl.hidden = false;
      return;
    }

    const yieldNum = document.getElementById('crop-yield-num').value.trim();
    const yieldUnit = document.getElementById('crop-yield-unit').value;
    const finalYield = yieldNum ? `${yieldNum} ${yieldUnit}` : '';

    const result = await postAction('croplog_create', {
      crop_name: cropName,
      notes: document.getElementById('crop-notes').value.trim(),
      yield: finalYield,
    });

    if (result.ok) {
      e.target.reset();
      loadCropLog();
    } else {
      alertEl.textContent = result.error || 'Could not save entry.';
      alertEl.hidden = false;
    }
  });
}

// ---------- Resources ----------

async function loadResources() {
  const res = await fetch('api.php?action=resources');
  const data = await res.json();
  if (!data.ok) return;

  const selectEl = document.getElementById('resource-select');
  if (selectEl) {
    selectEl.innerHTML = data.resources.map(r => `
      <option value="${r.ResourceID}" ${r.AvailableQty === 0 ? 'disabled' : ''}>
        ${escapeHtml(r.Name)} (${r.AvailableQty} left)
      </option>
    `).join('');
  }
}

async function loadMyRequests() {
  const res = await fetch('api.php?action=my_resource_requests');
  const data = await res.json();
  const el = document.getElementById('my-requests-list');
  if (!data.ok) return;

  if (data.requests.length === 0) {
    el.innerHTML = '<p class="text-muted" style="font-size: 0.85rem;">No requests yet.</p>';
    return;
  }

  const statusColor = {
    Requested: 'color: var(--brown-700);',
    Approved: 'color: var(--green-700); font-weight: 600;',
    Rejected: 'color: var(--danger); font-weight: 600;',
  };

  el.innerHTML = data.requests.map(r => `
    <div style="display:flex; justify-content: space-between; align-items:center; border-bottom: 1px solid var(--line); padding: 8px 0;">
      <span style="font-size: 0.88rem; color: var(--ink-900);">${escapeHtml(String(r.Qty))}x ${escapeHtml(r.Name)}</span>
      <span style="font-size: 0.85rem; ${statusColor[r.Status] || 'color: var(--ink-600);'}">
        ${escapeHtml(r.Status)}
      </span>
    </div>
  `).join('');
}

const resourceForm = document.getElementById('resource-form');
if (resourceForm) {
  resourceForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const alertEl = document.getElementById('resource-alert');
    alertEl.hidden = true;

    const resourceId = document.getElementById('resource-select').value;
    const qty = document.getElementById('resource-qty').value;

    const result = await postAction('resource_request', { resource_id: resourceId, qty });
    if (result.ok) {
      showToast('Resource requested!', 'success');
      loadResources();
      loadMyRequests();
    } else {
      alertEl.textContent = result.error || 'Could not submit request.';
      alertEl.hidden = false;
    }
  });
}

document.addEventListener('DOMContentLoaded', () => {
  loadPlot();
  loadCropLog();
  loadResources();
  loadMyRequests();
  setInterval(loadPlot, 5000);
});